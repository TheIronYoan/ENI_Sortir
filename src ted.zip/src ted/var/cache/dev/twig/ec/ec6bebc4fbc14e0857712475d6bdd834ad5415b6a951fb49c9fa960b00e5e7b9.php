<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_dcb7036015d0b9e174d4a8ef242c079665be4faded969a54573f14f2bee305c6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Eni-Sortir</title>

    <!-- Bootstrap core CSS -->
    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Custom fonts for this template -->
    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/fontawesome-free/css/all.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat:400,700\" rel=\"stylesheet\" type=\"text/css\">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/agency.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

</head>

<body id=\"page-top\">

<!-- Navigation -->
<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top\" id=\"mainNav\">
    <div class=\"container\">
        <a class=\"navbar-brand js-scroll-trigger\" href=\"#page-top\">Eni-Sortir</a>
        <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            Menu
            <i class=\"fas fa-bars\"></i>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">
            <ul class=\"navbar-nav text-uppercase ml-auto\">
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#services\">Services</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#portfolio\">Portfolio</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#about\">About</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#team\">Equipe</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#contact\">Contact</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#page-top\">Recherche</a>
                </li>
                ";
        // line 58
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 59
            echo "                    <li class=\"nav-item\">
                        <a class=\"nav-link\"href=\"";
            // line 60
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Se Déconnecter</a>
                    </li>
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            Menu
                        </a>
                        <ul class=\"dropdown-menu\" aria-labelledby=\"dropdownMenu8\">
                            <li> <a href=\"#page-top\">Ajouter un Pokémon</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Liste des Pokémons !</a> </li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"#\" title=\"Lien 4\">Lien 4</a></li>
                        </ul>
                    </li>
                ";
        } else {
            // line 76
            echo "
                    <li class=\"nav-item\"><a class=\"nav-link\" href=\"";
            // line 77
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
            echo "\">Se Connecter</a>
                    </li>
                    <li class=\"nav-item\"><a class=\"nav-link\" href=\"";
            // line 79
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_register");
            echo "\">Créer Un Compte</a>
                    </li>
                ";
        }
        // line 82
        echo "
            </ul>
        </div>
    </div>
</nav>

<!-- Header -->
<header class=\"masthead\">
    <div class=\"container\">
        <div class=\"intro-text\">
            <div class=\"intro-lead-in\">Bienvenue sur Eni-Sortir!</div>
            <div class=\"intro-heading text-uppercase\">Nous sommes heureux de vous voir ici</div>
            <a class=\"btn btn-primary btn-xl text-uppercase js-scroll-trigger\" href=\"#services\">PLus d'infos</a>
        </div>
    </div>
</header>

<!-- Services -->
<section class=\"page-section\" id=\"services\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Services</h2>
                <h3 class=\"section-subheading text-muted\">Le site internet comprends ces différents services.</h3>
            </div>
        </div>
        <div class=\"row text-center\">
            <div class=\"col-md-4\">
          <span class=\"fa-stack fa-4x\">
            <i class=\"fas fa-circle fa-stack-2x text-primary\"></i>
            <i class=\"fas fa-shopping-cart fa-stack-1x fa-inverse\"></i>
          </span>
                <h4 class=\"service-heading\">E-Commerce</h4>
                <p class=\"text-muted\">Le commerce électronique est l'activité d'achat ou de vente électronique de produits sur des services en ligne ou sur Internet.</p>
            </div>
            <div class=\"col-md-4\">
          <span class=\"fa-stack fa-4x\">
            <i class=\"fas fa-circle fa-stack-2x text-primary\"></i>
            <i class=\"fas fa-laptop fa-stack-1x fa-inverse\"></i>
          </span>
                <h4 class=\"service-heading\">Responsive Design</h4>
                <p class=\"text-muted\">La conception Web réactive ( RWD ) est une approche de la conception Web qui permet aux pages Web de s'afficher correctement sur une variété d'appareils et de tailles de fenêtres ou d'écrans.</p>
            </div>
            <div class=\"col-md-4\">
          <span class=\"fa-stack fa-4x\">
            <i class=\"fas fa-circle fa-stack-2x text-primary\"></i>
            <i class=\"fas fa-lock fa-stack-1x fa-inverse\"></i>
          </span>
                <h4 class=\"service-heading\">Web Security</h4>
                <p class=\"text-muted\">La sécurité des applications Web est une branche de la sécurité des informations qui traite spécifiquement de la sécurité des sites Web , des applications Web et des services Web.</p>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Grid -->
<section class=\"bg-light page-section\" id=\"portfolio\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Portfolio</h2>
                <h3 class=\"section-subheading text-muted\">Lorem ipsum dolor sit amet consectetur.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal1\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"";
        // line 154
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/01-thumbnail.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Threads</h4>
                    <p class=\"text-muted\">Illustration</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal2\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"";
        // line 168
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/02-thumbnail.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Explore</h4>
                    <p class=\"text-muted\">Graphic Design</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal3\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"";
        // line 182
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/03-thumbnail.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Finish</h4>
                    <p class=\"text-muted\">Identity</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal4\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"";
        // line 196
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/04-thumbnail.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Lines</h4>
                    <p class=\"text-muted\">Branding</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal5\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"";
        // line 210
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/05-thumbnail.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Southwest</h4>
                    <p class=\"text-muted\">Website Design</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal6\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/06-thumbnail.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Window</h4>
                    <p class=\"text-muted\">Photography</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About -->
<section class=\"page-section\" id=\"about\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">About</h2>
                <h3 class=\"section-subheading text-muted\">Lorem ipsum dolor sit amet consectetur.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <ul class=\"timeline\">
                    <li>
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"";
        // line 249
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/about/1.jpg"), "html", null, true);
        echo "\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>2009-2011</h4>
                                <h4 class=\"subheading\">Our Humble Beginnings</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li class=\"timeline-inverted\">
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"";
        // line 263
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/about/2.jpg"), "html", null, true);
        echo "\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>March 2011</h4>
                                <h4 class=\"subheading\">An Agency is Born</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"";
        // line 277
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/about/3.jpg"), "html", null, true);
        echo "\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>December 2012</h4>
                                <h4 class=\"subheading\">Transition to Full Service</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li class=\"timeline-inverted\">
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"";
        // line 291
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/about/4.jpg"), "html", null, true);
        echo "\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>July 2014</h4>
                                <h4 class=\"subheading\">Phase Two Expansion</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li class=\"timeline-inverted\">
                        <div class=\"timeline-image\">
                            <h4>Faites
                                <br>Parti
                                <br>De L'histoire!</h4>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Team -->
<section class=\"bg-light page-section\" id=\"team\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Votre Super Team</h2>
                <h3 class=\"section-subheading text-muted\">Admirer le talent l'éqquipe.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"";
        // line 328
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/team/teddy.jpg"), "html", null, true);
        echo "\" alt=\"\">
                    <h4>Teddy Marchand</h4>
                    <p class=\"text-muted\">Lead Designer-Dev Full-Stack</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"";
        // line 353
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/team/tank.jpg"), "html", null, true);
        echo "\" alt=\"\">
                    <h4>Yoan Le Sniffeur</h4>
                    <p class=\"text-muted\">Minecraft Pro-Player</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>


            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"";
        // line 379
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/team/bruno.jpg"), "html", null, true);
        echo "\" alt=\"\">
                    <h4>Bruno Parker</h4>
                    <p class=\"text-muted\">Lead Salade de Fruit</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"";
        // line 403
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/team/ironman.jpg"), "html", null, true);
        echo "\" alt=\"\">
                    <h4>Matthieu</h4>
                    <p class=\"text-muted\">Héro malgré lui !</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-lg-8 mx-auto text-center\">
                <p class=\"large text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
            </div>
        </div>
    </div>
</section>

<!-- Clients -->
<section class=\"py-5\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 440
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/logos/envato.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
            </div>
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 445
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/logos/designmodo.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
            </div>
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 450
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/logos/themeforest.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
            </div>
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 455
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/logos/creative-market.jpg"), "html", null, true);
        echo "\" alt=\"\">
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Contact -->
<section class=\"page-section\" id=\"contact\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Contact-nous !</h2>
                <h3 class=\"section-subheading text-muted\">.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <form id=\"contactForm\" name=\"sentMessage\" novalidate=\"novalidate\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <input class=\"form-control\" id=\"name\" type=\"text\" placeholder=\"Votre Nom *\" required=\"required\" data-validation-required-message=\"Please enter your name.\">
                                <p class=\"help-block text-danger\"></p>
                            </div>
                            <div class=\"form-group\">
                                <input class=\"form-control\" id=\"email\" type=\"email\" placeholder=\"Votre Email *\" required=\"required\" data-validation-required-message=\"Please enter your email address.\">
                                <p class=\"help-block text-danger\"></p>
                            </div>
                            <div class=\"form-group\">
                                <input class=\"form-control\" id=\"phone\" type=\"tel\" placeholder=\"Votre numéro de téléphone *\" required=\"required\" data-validation-required-message=\"Please enter your phone number.\">
                                <p class=\"help-block text-danger\"></p>
                            </div>
                        </div>
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <textarea class=\"form-control\" id=\"message\" placeholder=\"Votre Message *\" required=\"required\" data-validation-required-message=\"Please enter a message.\"></textarea>
                                <p class=\"help-block text-danger\"></p>
                            </div>
                        </div>
                        <div class=\"clearfix\"></div>
                        <div class=\"col-lg-12 text-center\">
                            <div id=\"success\"></div>
                            <button id=\"sendMessageButton\" class=\"btn btn-primary btn-xl text-uppercase\" type=\"submit\">Envoyer le Message</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class=\"footer\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-4\">
                <span class=\"copyright\">Copyright &copy; ENI-Sortir 2020</span>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline social-buttons\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-twitter\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-facebook-f\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-linkedin-in\"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline quicklinks\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Privacy Policy</a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Conditions D'utilisations</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Portfolio Modals -->

<!-- Modal 1 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal1\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 565
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/01-full.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Threads</li>
                                <li>Category: Illustration</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal2\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 599
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/02-full.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Explore</li>
                                <li>Category: Graphic Design</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 3 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal3\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 633
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/03-full.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Finish</li>
                                <li>Category: Identity</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 4 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal4\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 667
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/04-full.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Lines</li>
                                <li>Category: Branding</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 5 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal5\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 701
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/05-full.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Southwest</li>
                                <li>Category: Website Design</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 6 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal6\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"";
        // line 735
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/portfolio/06-full.jpg"), "html", null, true);
        echo "\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Window</li>
                                <li>Category: Photography</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript -->
<script src=\"";
        // line 754
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 755
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>

<!-- Plugin JavaScript -->
<script src=\"";
        // line 758
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/jquery-easing/jquery.easing.min.js"), "html", null, true);
        echo "\"></script>

<!-- Contact form JavaScript -->
<script src=\"";
        // line 761
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/jqBootstrapValidation.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 762
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/contact_me.js"), "html", null, true);
        echo "\"></script>

<!-- Custom scripts for this template -->
<script src=\"";
        // line 765
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/agency.min.js"), "html", null, true);
        echo "\"></script>

</body>

</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  921 => 765,  915 => 762,  911 => 761,  905 => 758,  899 => 755,  895 => 754,  873 => 735,  836 => 701,  799 => 667,  762 => 633,  725 => 599,  688 => 565,  575 => 455,  567 => 450,  559 => 445,  551 => 440,  511 => 403,  484 => 379,  455 => 353,  427 => 328,  387 => 291,  370 => 277,  353 => 263,  336 => 249,  308 => 224,  291 => 210,  274 => 196,  257 => 182,  240 => 168,  223 => 154,  149 => 82,  143 => 79,  138 => 77,  135 => 76,  116 => 60,  113 => 59,  111 => 58,  74 => 24,  64 => 17,  58 => 14,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Eni-Sortir</title>

    <!-- Bootstrap core CSS -->
    <link href=\"{{asset('vendor/bootstrap/css/bootstrap.min.css')}}\" rel=\"stylesheet\">

    <!-- Custom fonts for this template -->
    <link href=\"{{asset('vendor/fontawesome-free/css/all.min.css')}}\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat:400,700\" rel=\"stylesheet\" type=\"text/css\">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href=\"{{asset('css/agency.min.css')}}\" rel=\"stylesheet\">

</head>

<body id=\"page-top\">

<!-- Navigation -->
<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top\" id=\"mainNav\">
    <div class=\"container\">
        <a class=\"navbar-brand js-scroll-trigger\" href=\"#page-top\">Eni-Sortir</a>
        <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            Menu
            <i class=\"fas fa-bars\"></i>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">
            <ul class=\"navbar-nav text-uppercase ml-auto\">
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#services\">Services</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#portfolio\">Portfolio</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#about\">About</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#team\">Equipe</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#contact\">Contact</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#page-top\">Recherche</a>
                </li>
                {% if is_granted ('IS_AUTHENTICATED_REMEMBERED') %}
                    <li class=\"nav-item\">
                        <a class=\"nav-link\"href=\"{{ path('app_logout') }}\">Se Déconnecter</a>
                    </li>
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            Menu
                        </a>
                        <ul class=\"dropdown-menu\" aria-labelledby=\"dropdownMenu8\">
                            <li> <a href=\"#page-top\">Ajouter un Pokémon</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Liste des Pokémons !</a> </li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"#\" title=\"Lien 4\">Lien 4</a></li>
                        </ul>
                    </li>
                {%  else %}

                    <li class=\"nav-item\"><a class=\"nav-link\" href=\"{{ path('app_login') }}\">Se Connecter</a>
                    </li>
                    <li class=\"nav-item\"><a class=\"nav-link\" href=\"{{ path('user_register') }}\">Créer Un Compte</a>
                    </li>
                {%  endif %}

            </ul>
        </div>
    </div>
</nav>

<!-- Header -->
<header class=\"masthead\">
    <div class=\"container\">
        <div class=\"intro-text\">
            <div class=\"intro-lead-in\">Bienvenue sur Eni-Sortir!</div>
            <div class=\"intro-heading text-uppercase\">Nous sommes heureux de vous voir ici</div>
            <a class=\"btn btn-primary btn-xl text-uppercase js-scroll-trigger\" href=\"#services\">PLus d'infos</a>
        </div>
    </div>
</header>

<!-- Services -->
<section class=\"page-section\" id=\"services\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Services</h2>
                <h3 class=\"section-subheading text-muted\">Le site internet comprends ces différents services.</h3>
            </div>
        </div>
        <div class=\"row text-center\">
            <div class=\"col-md-4\">
          <span class=\"fa-stack fa-4x\">
            <i class=\"fas fa-circle fa-stack-2x text-primary\"></i>
            <i class=\"fas fa-shopping-cart fa-stack-1x fa-inverse\"></i>
          </span>
                <h4 class=\"service-heading\">E-Commerce</h4>
                <p class=\"text-muted\">Le commerce électronique est l'activité d'achat ou de vente électronique de produits sur des services en ligne ou sur Internet.</p>
            </div>
            <div class=\"col-md-4\">
          <span class=\"fa-stack fa-4x\">
            <i class=\"fas fa-circle fa-stack-2x text-primary\"></i>
            <i class=\"fas fa-laptop fa-stack-1x fa-inverse\"></i>
          </span>
                <h4 class=\"service-heading\">Responsive Design</h4>
                <p class=\"text-muted\">La conception Web réactive ( RWD ) est une approche de la conception Web qui permet aux pages Web de s'afficher correctement sur une variété d'appareils et de tailles de fenêtres ou d'écrans.</p>
            </div>
            <div class=\"col-md-4\">
          <span class=\"fa-stack fa-4x\">
            <i class=\"fas fa-circle fa-stack-2x text-primary\"></i>
            <i class=\"fas fa-lock fa-stack-1x fa-inverse\"></i>
          </span>
                <h4 class=\"service-heading\">Web Security</h4>
                <p class=\"text-muted\">La sécurité des applications Web est une branche de la sécurité des informations qui traite spécifiquement de la sécurité des sites Web , des applications Web et des services Web.</p>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Grid -->
<section class=\"bg-light page-section\" id=\"portfolio\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Portfolio</h2>
                <h3 class=\"section-subheading text-muted\">Lorem ipsum dolor sit amet consectetur.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal1\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"{{asset('img/portfolio/01-thumbnail.jpg')}}\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Threads</h4>
                    <p class=\"text-muted\">Illustration</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal2\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"{{asset('img/portfolio/02-thumbnail.jpg')}}\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Explore</h4>
                    <p class=\"text-muted\">Graphic Design</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal3\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"{{asset('img/portfolio/03-thumbnail.jpg')}}\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Finish</h4>
                    <p class=\"text-muted\">Identity</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal4\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"{{ asset('img/portfolio/04-thumbnail.jpg') }}\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Lines</h4>
                    <p class=\"text-muted\">Branding</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal5\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"{{ asset('img/portfolio/05-thumbnail.jpg') }}\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Southwest</h4>
                    <p class=\"text-muted\">Website Design</p>
                </div>
            </div>
            <div class=\"col-md-4 col-sm-6 portfolio-item\">
                <a class=\"portfolio-link\" data-toggle=\"modal\" href=\"#portfolioModal6\">
                    <div class=\"portfolio-hover\">
                        <div class=\"portfolio-hover-content\">
                            <i class=\"fas fa-plus fa-3x\"></i>
                        </div>
                    </div>
                    <img class=\"img-fluid\" src=\"{{ asset('img/portfolio/06-thumbnail.jpg') }}\" alt=\"\">
                </a>
                <div class=\"portfolio-caption\">
                    <h4>Window</h4>
                    <p class=\"text-muted\">Photography</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About -->
<section class=\"page-section\" id=\"about\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">About</h2>
                <h3 class=\"section-subheading text-muted\">Lorem ipsum dolor sit amet consectetur.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <ul class=\"timeline\">
                    <li>
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"{{ asset('img/about/1.jpg') }}\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>2009-2011</h4>
                                <h4 class=\"subheading\">Our Humble Beginnings</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li class=\"timeline-inverted\">
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"{{ asset('img/about/2.jpg') }}\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>March 2011</h4>
                                <h4 class=\"subheading\">An Agency is Born</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"{{asset('img/about/3.jpg')}}\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>December 2012</h4>
                                <h4 class=\"subheading\">Transition to Full Service</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li class=\"timeline-inverted\">
                        <div class=\"timeline-image\">
                            <img class=\"rounded-circle img-fluid\" src=\"{{ asset('img/about/4.jpg') }}\" alt=\"\">
                        </div>
                        <div class=\"timeline-panel\">
                            <div class=\"timeline-heading\">
                                <h4>July 2014</h4>
                                <h4 class=\"subheading\">Phase Two Expansion</h4>
                            </div>
                            <div class=\"timeline-body\">
                                <p class=\"text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p>
                            </div>
                        </div>
                    </li>
                    <li class=\"timeline-inverted\">
                        <div class=\"timeline-image\">
                            <h4>Faites
                                <br>Parti
                                <br>De L'histoire!</h4>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Team -->
<section class=\"bg-light page-section\" id=\"team\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Votre Super Team</h2>
                <h3 class=\"section-subheading text-muted\">Admirer le talent l'éqquipe.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"{{asset('img/team/teddy.jpg')}}\" alt=\"\">
                    <h4>Teddy Marchand</h4>
                    <p class=\"text-muted\">Lead Designer-Dev Full-Stack</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class=\"row\">
            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"{{asset('img/team/tank.jpg')}}\" alt=\"\">
                    <h4>Yoan Le Sniffeur</h4>
                    <p class=\"text-muted\">Minecraft Pro-Player</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>


            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"{{asset('img/team/bruno.jpg')}}\" alt=\"\">
                    <h4>Bruno Parker</h4>
                    <p class=\"text-muted\">Lead Salade de Fruit</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class=\"col-sm-4\">
                <div class=\"team-member\">
                    <img class=\"mx-auto rounded-circle\" src=\"{{asset('img/team/ironman.jpg')}}\" alt=\"\">
                    <h4>Matthieu</h4>
                    <p class=\"text-muted\">Héro malgré lui !</p>
                    <ul class=\"list-inline social-buttons\">
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-twitter\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-facebook-f\"></i>
                            </a>
                        </li>
                        <li class=\"list-inline-item\">
                            <a href=\"#\">
                                <i class=\"fab fa-linkedin-in\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-lg-8 mx-auto text-center\">
                <p class=\"large text-muted\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
            </div>
        </div>
    </div>
</section>

<!-- Clients -->
<section class=\"py-5\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/logos/envato.jpg')}}\" alt=\"\">
                </a>
            </div>
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/logos/designmodo.jpg')}}\" alt=\"\">
                </a>
            </div>
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/logos/themeforest.jpg')}}\" alt=\"\">
                </a>
            </div>
            <div class=\"col-md-3 col-sm-6\">
                <a href=\"#\">
                    <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/logos/creative-market.jpg')}}\" alt=\"\">
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Contact -->
<section class=\"page-section\" id=\"contact\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 text-center\">
                <h2 class=\"section-heading text-uppercase\">Contact-nous !</h2>
                <h3 class=\"section-subheading text-muted\">.</h3>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <form id=\"contactForm\" name=\"sentMessage\" novalidate=\"novalidate\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <input class=\"form-control\" id=\"name\" type=\"text\" placeholder=\"Votre Nom *\" required=\"required\" data-validation-required-message=\"Please enter your name.\">
                                <p class=\"help-block text-danger\"></p>
                            </div>
                            <div class=\"form-group\">
                                <input class=\"form-control\" id=\"email\" type=\"email\" placeholder=\"Votre Email *\" required=\"required\" data-validation-required-message=\"Please enter your email address.\">
                                <p class=\"help-block text-danger\"></p>
                            </div>
                            <div class=\"form-group\">
                                <input class=\"form-control\" id=\"phone\" type=\"tel\" placeholder=\"Votre numéro de téléphone *\" required=\"required\" data-validation-required-message=\"Please enter your phone number.\">
                                <p class=\"help-block text-danger\"></p>
                            </div>
                        </div>
                        <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <textarea class=\"form-control\" id=\"message\" placeholder=\"Votre Message *\" required=\"required\" data-validation-required-message=\"Please enter a message.\"></textarea>
                                <p class=\"help-block text-danger\"></p>
                            </div>
                        </div>
                        <div class=\"clearfix\"></div>
                        <div class=\"col-lg-12 text-center\">
                            <div id=\"success\"></div>
                            <button id=\"sendMessageButton\" class=\"btn btn-primary btn-xl text-uppercase\" type=\"submit\">Envoyer le Message</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class=\"footer\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-4\">
                <span class=\"copyright\">Copyright &copy; ENI-Sortir 2020</span>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline social-buttons\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-twitter\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-facebook-f\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-linkedin-in\"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline quicklinks\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Privacy Policy</a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Conditions D'utilisations</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Portfolio Modals -->

<!-- Modal 1 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal1\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/portfolio/01-full.jpg')}}\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Threads</li>
                                <li>Category: Illustration</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal2\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/portfolio/02-full.jpg')}}\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Explore</li>
                                <li>Category: Graphic Design</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 3 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal3\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"{{ asset('img/portfolio/03-full.jpg') }}\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Finish</li>
                                <li>Category: Identity</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 4 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal4\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"{{asset('img/portfolio/04-full.jpg')}}\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Lines</li>
                                <li>Category: Branding</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 5 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal5\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"{{ asset('img/portfolio/05-full.jpg') }}\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Southwest</li>
                                <li>Category: Website Design</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 6 -->
<div class=\"portfolio-modal modal fade\" id=\"portfolioModal6\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"close-modal\" data-dismiss=\"modal\">
                <div class=\"lr\">
                    <div class=\"rl\"></div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8 mx-auto\">
                        <div class=\"modal-body\">
                            <!-- Project Details Go Here -->
                            <h2 class=\"text-uppercase\">Project Name</h2>
                            <p class=\"item-intro text-muted\">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class=\"img-fluid d-block mx-auto\" src=\"{{ asset('img/portfolio/06-full.jpg') }}\" alt=\"\">
                            <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                            <ul class=\"list-inline\">
                                <li>Date: January 2017</li>
                                <li>Client: Window</li>
                                <li>Category: Photography</li>
                            </ul>
                            <button class=\"btn btn-primary\" data-dismiss=\"modal\" type=\"button\">
                                <i class=\"fas fa-times\"></i>
                                Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript -->
<script src=\"{{asset('vendor/jquery/jquery.min.js')}}\"></script>
<script src=\"{{asset('vendor/bootstrap/js/bootstrap.bundle.min.js')}}\"></script>

<!-- Plugin JavaScript -->
<script src=\"{{asset('vendor/jquery-easing/jquery.easing.min.js')}}\"></script>

<!-- Contact form JavaScript -->
<script src=\"{{asset('js/jqBootstrapValidation.js')}}\"></script>
<script src=\"{{asset('js/contact_me.js')}}\"></script>

<!-- Custom scripts for this template -->
<script src=\"{{asset('js/agency.min.js')}}\"></script>

</body>

</html>
", "base.html.twig", "F:\\wamp64\\www\\eni\\templates\\base.html.twig");
    }
}
