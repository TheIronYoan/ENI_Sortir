<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layout.html.twig */
class __TwigTemplate_3936878d6b81142ffab6fd5deeeea5562bef617e280ac875587a559289a2f758 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Eni-Sortir</title>

    <!-- Bootstrap core CSS -->
    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Custom fonts for this template -->
    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/fontawesome-free/css/all.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat:400,700\" rel=\"stylesheet\" type=\"text/css\">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/agency.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

</head>

<body id=\"page-top\">

<!-- Navigation -->
<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top\" id=\"mainNav\">
    <div class=\"container\">
        <a class=\"navbar-brand js-scroll-trigger\" href=\"";
        // line 33
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">Eni-Sortir</a>
        <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            Menu
            <i class=\"fas fa-bars\"></i>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">
            <ul class=\"navbar-nav text-uppercase ml-auto\">
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#page-top\">Recherche</a>
                </li>
                ";
        // line 43
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 44
            echo "                    <li class=\"nav-item\">
                        <a class=\"nav-link\"href=\"#page-top\">Se Déconnecter</a>
                    </li>
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            Menu
                        </a>
                        <ul class=\"dropdown-menu\" aria-labelledby=\"dropdownMenu8\">
                            <li> <a href=\"#page-top\">Ajouter un Pokémon</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Liste des Pokémons !</a> </li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"#\" title=\"Lien 4\">Lien 4</a></li>
                        </ul>
                    </li>
                ";
        }
        // line 61
        echo "
            </ul>
        </div>
    </div>
</nav>


";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 68, $this->source); })()), "flashes", [], "any", false, false, false, 68));
        foreach ($context['_seq'] as $context["label"] => $context["messages"]) {
            // line 69
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 70
                echo "        <div class=\"flash flash-";
                echo twig_escape_filter($this->env, $context["label"], "html", null, true);
                echo "\">
            ";
                // line 71
                echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        $this->displayBlock('main', $context, $blocks);
        // line 76
        echo "


<!-- Footer -->
<footer class=\"footer\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-4\">
                <span class=\"copyright\">Copyright &copy; ENI-Sortir 2020</span>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline social-buttons\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-twitter\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-facebook-f\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-linkedin-in\"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline quicklinks\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Privacy Policy</a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Conditions D'utilisations</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>

<!-- Plugin JavaScript -->
<script src=\"";
        // line 124
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendor/jquery-easing/jquery.easing.min.js"), "html", null, true);
        echo "\"></script>

<!-- Contact form JavaScript -->
<script src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/jqBootstrapValidation.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/contact_me.js"), "html", null, true);
        echo "\"></script>

<!-- Custom scripts for this template -->
<script src=\"";
        // line 131
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/agency.min.js"), "html", null, true);
        echo "\"></script>

</body>

</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 75
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        echo "  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  247 => 75,  231 => 131,  225 => 128,  221 => 127,  215 => 124,  209 => 121,  205 => 120,  159 => 76,  157 => 75,  144 => 71,  139 => 70,  134 => 69,  130 => 68,  121 => 61,  102 => 44,  100 => 43,  87 => 33,  75 => 24,  65 => 17,  59 => 14,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Eni-Sortir</title>

    <!-- Bootstrap core CSS -->
    <link href=\"{{asset('vendor/bootstrap/css/bootstrap.min.css')}}\" rel=\"stylesheet\">

    <!-- Custom fonts for this template -->
    <link href=\"{{asset('vendor/fontawesome-free/css/all.min.css')}}\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Montserrat:400,700\" rel=\"stylesheet\" type=\"text/css\">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href=\"{{asset('css/agency.min.css')}}\" rel=\"stylesheet\">

</head>

<body id=\"page-top\">

<!-- Navigation -->
<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top\" id=\"mainNav\">
    <div class=\"container\">
        <a class=\"navbar-brand js-scroll-trigger\" href=\"{{ path('accueil') }}\">Eni-Sortir</a>
        <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            Menu
            <i class=\"fas fa-bars\"></i>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">
            <ul class=\"navbar-nav text-uppercase ml-auto\">
                <li class=\"nav-item\">
                    <a class=\"nav-link js-scroll-trigger\" href=\"#page-top\">Recherche</a>
                </li>
                {% if is_granted ('IS_AUTHENTICATED_REMEMBERED') %}
                    <li class=\"nav-item\">
                        <a class=\"nav-link\"href=\"#page-top\">Se Déconnecter</a>
                    </li>
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                            Menu
                        </a>
                        <ul class=\"dropdown-menu\" aria-labelledby=\"dropdownMenu8\">
                            <li> <a href=\"#page-top\">Ajouter un Pokémon</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Ajouter un Pokémon !</a> </li>
                            <li> <a href=\"#page-top\">Liste des Pokémons !</a> </li>
                            <li role=\"separator\" class=\"divider\"></li>
                            <li><a href=\"#\" title=\"Lien 4\">Lien 4</a></li>
                        </ul>
                    </li>
                {%  endif %}

            </ul>
        </div>
    </div>
</nav>


{% for label, messages in app.flashes %}
    {% for message in messages %}
        <div class=\"flash flash-{{ label }}\">
            {{ message }}
        </div>
    {% endfor %}
{% endfor %}
{%     block main  %}  {%  endblock  %}



<!-- Footer -->
<footer class=\"footer\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-4\">
                <span class=\"copyright\">Copyright &copy; ENI-Sortir 2020</span>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline social-buttons\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-twitter\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-facebook-f\"></i>
                        </a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">
                            <i class=\"fab fa-linkedin-in\"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class=\"col-md-4\">
                <ul class=\"list-inline quicklinks\">
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Privacy Policy</a>
                    </li>
                    <li class=\"list-inline-item\">
                        <a href=\"#\">Conditions D'utilisations</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src=\"{{asset('vendor/jquery/jquery.min.js')}}\"></script>
<script src=\"{{asset('vendor/bootstrap/js/bootstrap.bundle.min.js')}}\"></script>

<!-- Plugin JavaScript -->
<script src=\"{{asset('vendor/jquery-easing/jquery.easing.min.js')}}\"></script>

<!-- Contact form JavaScript -->
<script src=\"{{asset('js/jqBootstrapValidation.js')}}\"></script>
<script src=\"{{asset('js/contact_me.js')}}\"></script>

<!-- Custom scripts for this template -->
<script src=\"{{asset('js/agency.min.js')}}\"></script>

</body>

</html>
", "layout.html.twig", "F:\\wamp64\\www\\eni\\templates\\layout.html.twig");
    }
}
